﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace crud
{
    public partial class Form1 : Form
    {
        // DB 연결객체
        SqlConnection sqlconnection = new SqlConnection(
            @"Data Source=KB-PC\SQLEXPRESS;Initial Catalog=testdb;Persist Security Info=True;User ID=sa;Password=1234"
        );

        // select , update , insert , delete = java prepareStament
        SqlCommand sqlcommand = null;
        // java = > ResultSet 
        SqlDataAdapter sda = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void display()
        {
            sqlconnection.Open();

            DataTable dt = new DataTable();
            sqlcommand = new SqlCommand("select aa,bb as 'bb값',cc as 'cc값',dd,ee from test");
            sda = new SqlDataAdapter(sqlcommand.CommandText, sqlconnection);
            sda.Fill(dt);

            dataGridView1.DataSource = dt;
            sqlconnection.Close();

            dataGridView1.Columns[0].HeaderText = "첫번째컬럼";
        }

        /// <summary>
        ///     select 버튼 누르기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            display();
        }

        private void insertClick(object sender, EventArgs e)
        {
            sqlconnection.Open();

            sqlcommand = new SqlCommand("insert into test values(@aa,@bb,@cc,@dd,@ee)", sqlconnection);
            sqlcommand.Parameters.AddWithValue("@aa", textBox1.Text);
            sqlcommand.Parameters.AddWithValue("@bb", textBox2.Text);
            sqlcommand.Parameters.AddWithValue("@cc", textBox3.Text);
            sqlcommand.Parameters.AddWithValue("@dd", textBox4.Text);
            sqlcommand.Parameters.AddWithValue("@ee", textBox5.Text);
            sqlcommand.ExecuteNonQuery();
            sqlconnection.Close();

            MessageBox.Show("insert 완료");

            display();

            //MessageBox.Show(textBox1.Text);
            //MessageBox.Show(textBox2.Text);
            //MessageBox.Show(textBox3.Text);
            //MessageBox.Show(textBox4.Text);
            //MessageBox.Show(textBox5.Text);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show("datagridview 클릭 "+e.RowIndex);

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            textBox1.Text = row.Cells[0].Value.ToString();
            textBox2.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
            textBox4.Text = row.Cells[3].Value.ToString();
            textBox5.Text = row.Cells[4].Value.ToString();
        }

        /// <summary>
        /// update 버튼 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            sqlconnection.Open();

            sqlcommand = new SqlCommand("update test " +
                "set aa = @aa,bb = @bb, cc= @cc, dd= @dd, ee = @ee", sqlconnection);
            sqlcommand.Parameters.AddWithValue("@aa", textBox1.Text);
            sqlcommand.Parameters.AddWithValue("@bb", textBox2.Text);
            sqlcommand.Parameters.AddWithValue("@cc", textBox3.Text);
            sqlcommand.Parameters.AddWithValue("@dd", textBox4.Text);
            sqlcommand.Parameters.AddWithValue("@ee", textBox5.Text);
            sqlcommand.ExecuteNonQuery();
            sqlconnection.Close();

            MessageBox.Show("insert 완료");

            display();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sqlconnection.Open();

            sqlcommand = new SqlCommand("delete from test", sqlconnection);
            sqlcommand.ExecuteNonQuery();

            sqlconnection.Close();

            MessageBox.Show("insert 완료");

            display();
        }
    }
}
