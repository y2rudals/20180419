show databases;
use munggu;
show tables;

create table user
(
	idx int(30),
    name varchar(100)
);

drop table user;

insert into user values(3,'qer');

select * from user;

create table freeboard(
	idx int(30) primary key auto_increment,
    title varchar(100),
    content varchar(300),
    regdate varchar(30),
    read_cnt int(10)
);

drop table freeboard;

select * from freeboard order by idx desc;

insert into freeboard 
(title,content,regdate,read_cnt)
values
('제목','내용',now(),0);

select count(*) from freeboard;

select * from freeboard
order by idx desc
limit 0,10








