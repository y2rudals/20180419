package com.munggu.org;

public class MemberDao {

	public void doselect() {
		
	}
}
