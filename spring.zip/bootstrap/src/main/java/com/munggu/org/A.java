package com.munggu.org;

import org.springframework.stereotype.Component;

@Component
public class A {

}
