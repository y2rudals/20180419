package com.munggu.org;

import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MybatisTester {

	@Test
	public void test() {
		try {
		ApplicationContext ctx = new GenericXmlApplicationContext("classpath:root-context.xml");

		DefaultSqlSessionFactory sqlSessionFactory = ctx.getBean("sqlSessionFactory",DefaultSqlSessionFactory.class);
//		PropertiesBeanDefinitionReader propReader = new PropertiesBeanDefinitionReader(ctx);
//		propReader.loadBeanDefinitions(new ClassPathResource("otherBeans.properties"));
//		try (DefaultSqlSessionFactory session = sqlSessionFactory.openSession()) {
//            System.out.println(session);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
