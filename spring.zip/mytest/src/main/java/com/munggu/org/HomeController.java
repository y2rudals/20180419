package com.munggu.org;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@Autowired
	SqlSession sqlSession;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );

		sqlSession.insert("mappers.testinsert",new User());
		
		List<User> al= sqlSession.selectList("mappers.test",new User(1,"qq"));
		for(User a : al) {
			System.out.println(a);
		}
		
		return "home";
	}
	
	@RequestMapping(value = "/aa", method = RequestMethod.GET)
	public String aa(Locale locale, Model model) {
		return "aa";
	}
	
	@RequestMapping(value = "/bb", method = RequestMethod.GET)
	public String bb(Locale locale, Model model) {
		return "bb";
	}
	
	@RequestMapping(value = "/cc", method = RequestMethod.GET)
	public String cc(Locale locale, Model model) {
		return "cc";
	}
	
}
